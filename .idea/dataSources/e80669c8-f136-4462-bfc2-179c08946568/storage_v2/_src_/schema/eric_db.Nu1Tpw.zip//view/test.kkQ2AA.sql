create view test as
  select `eric_db`.`student`.`id` AS `id`
  from `eric_db`.`student`;

